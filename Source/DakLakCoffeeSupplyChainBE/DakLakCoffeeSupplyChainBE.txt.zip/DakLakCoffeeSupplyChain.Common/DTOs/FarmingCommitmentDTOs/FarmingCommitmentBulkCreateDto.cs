﻿namespace DakLakCoffeeSupplyChain.Common.DTOs.FarmingCommitmentDTOs
{
    public class FarmingCommitmentBulkCreateDto
    {
        public List <FarmingCommitmentCreateDto> FarmingCommitmentCreateDtos { get; set; } = [];
    }
}
