﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DakLakCoffeeSupplyChain.Common.DTOs.ProcessingMethodDTOs
{
    public class ProcessingMethodDeleteDto
    {
        public int MethodId { get; set; }
    }
}
