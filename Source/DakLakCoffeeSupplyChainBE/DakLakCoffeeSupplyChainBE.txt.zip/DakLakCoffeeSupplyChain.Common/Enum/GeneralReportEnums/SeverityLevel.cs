﻿namespace DakLakCoffeeSupplyChain.Common.Enum.GeneralReportEnums
{
    public enum SeverityLevel
    {
        Low = 0,
        Medium = 1,
        High = 2
    }
}
