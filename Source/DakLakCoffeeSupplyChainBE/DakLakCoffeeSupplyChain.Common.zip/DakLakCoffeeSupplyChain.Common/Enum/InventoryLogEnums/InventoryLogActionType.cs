﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DakLakCoffeeSupplyChain.Common.Enum.InventoryLogEnums
{
    public enum InventoryLogActionType
    {
        increase,  // Nhập kho
        decrease   // Xuất kho
    }
}
