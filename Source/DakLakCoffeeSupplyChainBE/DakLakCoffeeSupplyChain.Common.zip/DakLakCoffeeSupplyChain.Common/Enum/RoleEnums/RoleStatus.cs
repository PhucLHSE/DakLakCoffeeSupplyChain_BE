﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DakLakCoffeeSupplyChain.Common.Enum.RoleEnums
{
    public enum RoleStatus
    {
        Active = 1,
        Inactive = 0
    }
}
