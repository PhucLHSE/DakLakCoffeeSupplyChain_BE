﻿namespace DakLakCoffeeSupplyChain.Common.Enum.GeneralReportEnums
{
    public enum ReportTypeEnum
    {
        Crop = 1,        // Báo cáo mùa vụ
        Processing = 2   // Báo cáo sơ chế
    }
}
