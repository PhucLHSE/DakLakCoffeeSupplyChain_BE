﻿using DakLakCoffeeSupplyChain.Common.Enum.CultivationRegistrationEnums;

namespace DakLakCoffeeSupplyChain.Common.DTOs.CultivationRegistrationDTOs
{
    public class CultivationRegistrationUpdateStatusDto
    {
        public CultivationRegistrationStatus Status { get; set; }
    }
}
