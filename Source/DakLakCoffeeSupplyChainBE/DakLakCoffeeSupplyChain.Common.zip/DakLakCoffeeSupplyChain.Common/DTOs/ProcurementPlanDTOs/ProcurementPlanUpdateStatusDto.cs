﻿using DakLakCoffeeSupplyChain.Common.Enum.ProcurementPlanEnums;

namespace DakLakCoffeeSupplyChain.Common.DTOs.ProcurementPlanDTOs
{
    public class ProcurementPlanUpdateStatusDto
    {
        public ProcurementPlanStatus Status { get; set; }
    }
}
